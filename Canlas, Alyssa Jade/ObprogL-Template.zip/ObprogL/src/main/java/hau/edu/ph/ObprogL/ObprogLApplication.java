package hau.edu.ph.ObprogL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObprogLApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObprogLApplication.class, args);
	}

}
